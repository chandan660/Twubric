@extends('layouts.app')

@section('content')
    <div class="panel-heading">Profile</div>
    <div class="panel-body">
        {{ $username }}
    </div>
@endsection
