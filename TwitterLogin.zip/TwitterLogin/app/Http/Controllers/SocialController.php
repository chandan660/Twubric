<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator,Redirect,Response,File;
use Socialite;
use Session;
use App\User;
class SocialController extends Controller
{

    public function redirect($provider)
    {
        return Socialite::driver($provider)->redirect();
    }

    public function callback($provider)
    {

        $getInfo = Socialite::driver($provider)->user();
        $refined_data=$this->twubric($getInfo['friends_count'],$getInfo['followers_count'],$getInfo['listed_count'],$getInfo['favourites_count'],$getInfo['statuses_count']);
        Session::put('refined_data', json_encode($refined_data));
        $user = $this->createUser($getInfo,$provider);

        auth()->login($user);

        return redirect()->to('/home');

    }
    function createUser($getInfo,$provider){

        $user = User::where('provider_id', $getInfo->id)->first();

        if (!$user) {
            $user = User::create([
                'name'     => $getInfo->name,
                'email'    => $getInfo->email,
                'provider' => $provider,
                'provider_id' => $getInfo->id
            ]);
        }
        return $user;
    }

    function twubric($friend,$follower,$list,$favourites,$status){
        $friend_twubric=$friend/$follower;
        $influence_twubric=$status/($friend+$follower+$list+$favourites);
        $chirpy_twubric=$follower/$friend;
        $friend_model=$this->friend($friend_twubric);
        $influence_model=$this->influence($influence_twubric);
        $chirpy_model=$this->chirpy($chirpy_twubric);
        $total=$friend_model+$influence_model+$chirpy_model;
        $model_data=array('twitter'=>array(
                                            'followers_count'=>$follower,
                                            'friends_count'=>$friend,
                                            'listed_count'=>$list,
                                            'favourites_count'=>$favourites,
                                            'statuses_count'=>$status),
                         'twubric'=>array(
                                            'total'=>$total,
                                            'friends'=>$friend_model,
                                            'influence'=>$influence_model,
                                            'chirpy'=>$chirpy_model));
        return $model_data;

    }

    function friend($friend_twubric){
        if($friend_twubric>=2)
            $friend_twubric=2;
        elseif ($friend_twubric<2 && $friend_twubric>1)
            $friend_twubric=1.5;
        elseif ($friend_twubric<1 && $friend_twubric>0)
            $friend_twubric=1;
        else
            $friend_twubric=0;
        return $friend_twubric;
    }

    function influence($influence_twubric){
        if($influence_twubric>=4)
            $influence_twubric=4;
        elseif ($influence_twubric<4 && $influence_twubric>3)
            $influence_twubric=3;
        elseif ($influence_twubric<3 && $influence_twubric>2)
            $influence_twubric=2;
        else
            $influence_twubric=1;
        return $influence_twubric;
    }

    function chirpy($chirpy_twubric){
        if($chirpy_twubric>=4)
            $chirpy_twubric=4;
        elseif ($chirpy_twubric<4 && $chirpy_twubric>3)
            $chirpy_twubric=3;
        elseif ($chirpy_twubric<3 && $chirpy_twubric>2)
            $chirpy_twubric=2;
        else
            $chirpy_twubric=1;
        return $chirpy_twubric;
    }
}