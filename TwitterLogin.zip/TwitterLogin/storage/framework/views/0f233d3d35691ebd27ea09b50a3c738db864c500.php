<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login With Twitter</div>

                <div class="panel-body">
                    <div class="form-group row mb-0">
                        <div class="col-md-12 offset-md-4">
                            <center><a href="<?php echo e(url('/auth/redirect/twitter')); ?>" class="btn btn-primary"><i class="fa fa-twitter"></i> Twitter</a></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>